import React from 'react';
import { render, screen } from '@testing-library/react';
import Button from './Button';

test('Button is visible', () => {
  render(<Button label="Click Me" />);
  const buttonElement = screen.getByText('Click Me');
  expect(buttonElement).toBeInTheDocument();
});

test('Button changes background color when disabled', () => {
  render(<Button label="Click Me" disabled />);
  const buttonElement = screen.getByText('Click Me');
  expect(buttonElement).toHaveStyle('background-color: gray');
});
