// index.ts
export { default as Button } from './Button';
