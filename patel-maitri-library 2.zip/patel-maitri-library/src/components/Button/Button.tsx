import React from 'react';
import styled, { css } from 'styled-components';

// Define the styled Button component
const StyledButton = styled.button`
  /* Default styles */
  background-color: Red;
  color: white;
  padding: 20px 20px;
  border: none;
  border-radius: 5px;
  font-size:20px;
  cursor: pointer;

  /* Responsive styles */
  @media (max-width: 768px) {
    /* Add responsive styles */
  }

  /* Disabled styles */
  ${(props) =>
    props.disabled &&
    css`
      background-color: gray;
      cursor: not-allowed;
    `}
`;

// Button component
export interface ButtonProps {
  label: string;
  disabled?: boolean;
  onClick?: () => void;
}

const Button: React.FC<ButtonProps> = ({ label, disabled = false, onClick }) => {
  return (
    <StyledButton disabled={disabled} onClick={onClick}>
      {label}
    </StyledButton>
  );
};

export default Button;
