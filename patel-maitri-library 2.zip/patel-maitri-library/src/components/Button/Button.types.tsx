// Button.types.tsx
export interface ButtonProps {
    onClick: () => void;
    label: string;
}
